package com.facebookweb.dao;

import com.facebookweb.entity.FacebookEmployee;

public interface FacebookDAOInterface {

	int createProfileDao(FacebookEmployee fe);

}
