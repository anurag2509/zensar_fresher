package com.facebookweb.service;

import com.facebookweb.entity.FacebookEmployee;

public interface FacebookServiceInterface {

	int createProfileService(FacebookEmployee fe);

}
